var playing = false;
var score;
var trialsleft;
var fruits = ['apple', 'banana', 'cherry', 'grapes', 'mango', 'orange', 'peach', 'pear', 'pinapple', 'watermelon'];

$(function(){
    
    // Click on the start / reset button 
    $("#startreset").click(function(){
      
        // We are playing?
        if(playing == true){
        
            // Reload our page
            location.reload();  
        }else{
            
            // We are not playing
            playing = true; // Fruit Game initiated
            
            // Set score to 0
            score = 0;
            $("#scorevalue").html(score);
     
            // Show trials left
            $("#trialsleft").show();
            trialsleft = 3;
            addhearts();
            
            // Hide game over box
            $("#gameOver").hide();
            
            // Change button text to reset game
            $("#startreset").html("Reset Game!");
            
            // Start sending fruits
            
            startAction();
        }
    });
  
  $("#fruit1").mouseover(function(){
   score++;
  $("#scorevalue").html(score);
  
  //   document.getElementById("slicesound").play();
      
     $("#slicesound")[0].play() // Play sound
      
      // Stop fruit
      clearInterval(action);
      
      // Hide fruit
      $("#fruit1").hide( "explode", ); // Slice fruit
      
      // Stop fruit and hide it
      stopAction();
      
      // Send new fruit
      setTimeout(startAction, 500);
  });
      
      
  
  // Slice a fruit
  // Play sound in the background
  // Explode the fruit
  
  
  // functions
  
  function addhearts(){
      $("#trialsleft").empty();
      for(i=0; i<trialsleft; i++){
      
          $("#trialsleft").append('<img src="images/heart.png" class="life">');
     }
  }
  
  // Start sending fruits
  
  function startAction(){
      
  // Generate a fruit    
    $("#fruit1").show();
    chooseFruit(); //Choose a random fruit
      $("#fruit1").css({'left' : Math.round(550 * Math.random()), 'top' : -50});
  // Random position
      
  // Generate a random step - between 1 and 6
      step = 1 + Math.round(5 * Math.random());
  // Change step
  
  // Move fruit down by 1 step every 10ms
      action = setInterval(function(){
      
  // Move fruit down by one step
        $("#fruit1").css('top', $("#fruit1").position().top + step);
          
  // Check if the fruit is too low
          
        if($("#fruit1").position().top > $("#fruitsContainer").height()){
  
  // Check if we have any trials left
            
        if(trialsleft > 1){
         // Generate a fruit    
    $("#fruit1").show();
    
  chooseFruit(); //Choose a random fruit
  
  $("#fruit1").css({'left' : 
  Math.round(550 * Math.random()), 'top' : -50});
  // Random position
            
  // Generate a random step - between 1 and 6
  
  step = 1 + Math.round(5 * Math.random());
        
      // Reduce trials by one
      trialsleft --;
            
      // Populate trialsleft box
      addhearts();
            
        }else{ // Game over
  
            playing = false; // We are not playing anymore
            
            $("#startreset").html("Start Game"); // Change button to start game
            $("#gameOver").show();
            $("#gameOver").html('<p>Game Over!</p><p>Your score is ' + score + '</p>');
            $("#trialsleft").hide();
            stopAction();
          
          }
        }    
      }, 10);
  }
  
  // Generate a random fruit
  
  function chooseFruit(){
    $("#fruit1").attr('src','images/' + fruits[Math.round(8 * Math.random())] + '.png');
  }
  
  // Stop dropping fruits
  
  function stopAction(){
    clearInterval(action);
    $("#fruit1").hide();
  }
 
});
  
  
  
  
  
  